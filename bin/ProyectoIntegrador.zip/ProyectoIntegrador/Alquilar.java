package ProyectoIntegrador;

import java.awt.Button;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;

import javax.print.DocFlavor.READER;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFormattedTextField;

public class Alquilar extends Recursos{

	private JFrame frame;
	private Button button_1;
	private JTable table;
	static Alquilar window = new Alquilar();
	static Devolver devolver = new Devolver();
	static  Recursos recurso ;

	private DefaultTableModel modelo;
	static Devolver windowDevolver = new Devolver();
	static	ProyectoIntegrador proyect = new ProyectoIntegrador();
	static 	GestorAlquiler gestor = new GestorAlquiler();

	// Gestor de los Recursos
	private Recursos recursos = new Recursos();
	private ArrayList<Recursos> listaDisponibles = new ArrayList<>();
	private JTextField txtDdmmaa;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @wbp.parser.entryPoint
	 */
	public Alquilar() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame();
		frame.setBounds(100, 100, 448, 202);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Alquiler");
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.PLAIN, 25));
		lblNewLabel.setBounds(166, 10, 104, 44);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Alquilar");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				recurso.setFecha(txtDdmmaa.getText());
				
				cerrarVista();
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton.setBounds(124, 104, 166, 39);
		frame.getContentPane().add(btnNewButton);
		btnNewButton.setEnabled(false);
		
		txtDdmmaa = new JTextField();
		txtDdmmaa.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (txtDdmmaa.getText().equalsIgnoreCase("0") || txtDdmmaa.getText().equalsIgnoreCase("1")||txtDdmmaa.getText().equalsIgnoreCase("2")||txtDdmmaa.getText().equalsIgnoreCase("3")) {
					btnNewButton.setEnabled(true);
				}
			}
		});
		txtDdmmaa.setBounds(158, 64, 96, 19);
		frame.getContentPane().add(txtDdmmaa);
		txtDdmmaa.setColumns(10);

		
		JButton btnNewButton_1 = new JButton("Volver");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				gestor.abrirVista();
				window.cerrarVista();
			}
		});
		btnNewButton_1.setBounds(10, 122, 85, 21);
		frame.getContentPane().add(btnNewButton_1);

		
		modelo = new DefaultTableModel(new Object[][] {},
				new String[] { "Nombre", "Ubicacion", "Fecha", "codigoPostal", "disponibilidad" });
		
		JLabel lblNewLabel_1 = new JLabel("Fecha: ");
		lblNewLabel_1.setBounds(100, 65, 56, 16);
		frame.getContentPane().add(lblNewLabel_1);
		
		
		// Recursos
		Recursos batmovil = new Recursos("Batmovil", "Gotam", "27/02/1924", 67425, false,1);
		Recursos batCinturon = new Recursos("Bat Cinturon", "Gotam", "27/02/1924", 67425, false,0);
		Recursos bastonAbuela = new Recursos("Baston de la abuela", "NYC", "19/04/1965", 38402, false,0);
		Recursos chancla = new Recursos("Chancla", "Bogota", "18/12/1999", 33202, false,0);
		Recursos capaSuperman = new Recursos("Capa de Superman", "LongVille", "12/02/1979", 49310, false,0);
		Recursos raton = new Recursos("Lab Rat (Eduardo)", "EEUU", "10/01/1889", 37921, false,0);

		recursos.anadirDis(batmovil);
		recursos.anadirDis(batCinturon);
		recursos.anadirDis(bastonAbuela);
		recursos.anadirDis(chancla);
		recursos.anadirDis(capaSuperman);
		recursos.anadirDis(raton);
		inicializarDatos();

	}
	
	public void inicializarDatos() {		
		// Innicializar datos metodo
		Object[] obj = new Object[5];
		listaDisponibles = recursos.getListaDisponibles();

		for (int i = 0; i < listaDisponibles.size(); i++) {

			obj[0] = listaDisponibles.get(i).getNombre();
			obj[1] = listaDisponibles.get(i).getUbicacion();
			obj[2] = listaDisponibles.get(i).getFecha();
			obj[3] = listaDisponibles.get(i).getCodigoPostal();
			obj[4] = listaDisponibles.get(i).getDisponibilidad();

			modelo.addRow(obj);

		}
	}
	

	public void alquilar(Recursos recursos) {
		devolver.anadirlista(recursos);
		eliminarlista(recursos);
	}
	public void eliminarlista(Recursos recurso) {
		listaDisponibles.remove(recurso);
	}
	

	public void anadirlista(Recursos recurso) {
		listaDisponibles.add(recurso);
	}
	public void cerrarVista() {

		window.frame.setVisible(false);

	}

	public void abrirVista() {

		window.frame.setVisible(true);

	}
	
	public void setRecurso(Recursos recurso) {
		this.recurso = recurso;
	}

	private static void addPopup(Component component, final JPopupMenu popup) {
	}

	public JTable getTable() {
		return getTable();
	}
}
