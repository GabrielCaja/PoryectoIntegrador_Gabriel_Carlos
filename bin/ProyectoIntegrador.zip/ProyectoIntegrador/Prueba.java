package ProyectoIntegrador;

import java.util.Iterator;

public class Prueba {

	public Prueba() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.err.println("Intento1 ");
		for (int i = 0; i < 10; i++) {
			System.out.println(i +" "+ i );
			System.out.println(i +" "+ (i+1));

		}
		
		System.err.println("intento2 ");
		
		for (int i = 0; i < 10; i++) {
			System.out.println(i +" "+ i );
			for (int w = 0; w <2; w++) {
				
			}
		}
		
	}

}
